<?php
    //Database connection parameters
    define("dbname","starr");
    define("Server","localhost");
    define("username","root");
    define("password","");
    
    ?>